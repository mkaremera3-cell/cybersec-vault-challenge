#!/bin/bash

################################################################################
# Script Name: vault_monitor.sh
# Description: Security monitoring and audit tool for the secure vault
#              Analyzes permissions, file metadata, and generates reports
# Author: CyberSec Ops Team
# Date: 2026-02-08
################################################################################

# Color codes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Define vault directory
VAULT_DIR="$HOME/secure_vault"
REPORT_FILE="$VAULT_DIR/vault_report.txt"

echo -e "${BLUE}╔════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║      VAULT SECURITY MONITORING SYSTEM      ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════╝${NC}"
echo ""

# Check if vault exists
if [ ! -d "$VAULT_DIR" ]; then
    echo -e "${RED}ERROR: Vault directory not found!${NC}"
    echo "Please run vault_setup.sh first."
    exit 1
fi

echo -e "${GREEN}✓ Vault located: $VAULT_DIR${NC}"
echo "Analyzing vault security..."
echo ""

# Initialize report
{
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║           SECURE VAULT SECURITY AUDIT REPORT               ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo ""
    echo "Report Generated: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "Vault Location: $VAULT_DIR"
    echo ""
    echo "================================================================"
    echo "                     FILE ANALYSIS"
    echo "================================================================"
    echo ""
} > "$REPORT_FILE"

# Flag to track if any security risks are detected
security_risk=false

# Process each file in the vault
for file in "$VAULT_DIR"/*.txt; do
    # Skip if no .txt files found
    [ -e "$file" ] || continue
    
    filename=$(basename "$file")
    
    # Get file information
    filesize=$(stat -c%s "$file" 2>/dev/null || stat -f%z "$file" 2>/dev/null)
    modified=$(stat -c%y "$file" 2>/dev/null | cut -d' ' -f1,2 || stat -f%Sm "$file" 2>/dev/null)
    permissions=$(stat -c%a "$file" 2>/dev/null || stat -f%A "$file" 2>/dev/null)
    perm_symbolic=$(ls -l "$file" | awk '{print $1}')
    
    echo -e "${CYAN}─────────────────────────────────────${NC}"
    echo -e "${YELLOW}File: $filename${NC}"
    echo "Size: $filesize bytes"
    echo "Last Modified: $modified"
    echo "Permissions: $permissions ($perm_symbolic)"
    
    # Write to report
    {
        echo "─────────────────────────────────────────────────────────"
        echo "File Name: $filename"
        echo "Size: $filesize bytes"
        echo "Last Modified: $modified"
        echo "Permissions: $permissions ($perm_symbolic)"
    } >> "$REPORT_FILE"
    
    # Security check: permissions more open than 644
    if [ "$permissions" -gt 644 ]; then
        echo -e "${RED}⚠️  SECURITY RISK DETECTED${NC}"
        echo -e "${RED}   Permissions are more permissive than recommended (644)${NC}"
        
        {
            echo "STATUS: ⚠️ SECURITY RISK DETECTED"
            echo "ISSUE: Permissions more permissive than 644"
        } >> "$REPORT_FILE"
        
        security_risk=true
    else
        echo -e "${GREEN}✓ Security status: OK${NC}"
        echo "STATUS: ✓ OK" >> "$REPORT_FILE"
    fi
    
    echo "" >> "$REPORT_FILE"
    echo ""
done

# Add summary to report
{
    echo "================================================================"
    echo "                     SECURITY SUMMARY"
    echo "================================================================"
    echo ""
    
    if [ "$security_risk" = true ]; then
        echo "Overall Status: ⚠️ SECURITY RISKS DETECTED"
        echo ""
        echo "RECOMMENDATIONS:"
        echo "  • Review and restrict file permissions"
        echo "  • Keys should be 600 (rw-------)"
        echo "  • Secrets should be 640 (rw-r-----) or more restrictive"
        echo "  • Logs can be 644 (rw-r--r--) at most"
    else
        echo "Overall Status: ✓ ALL SECURITY CHECKS PASSED"
        echo ""
        echo "All files have appropriate permission levels."
    fi
    
    echo ""
    echo "================================================================"
    echo "Report End: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "================================================================"
} >> "$REPORT_FILE"

# Display summary
echo -e "${CYAN}─────────────────────────────────────${NC}"
echo ""

if [ "$security_risk" = true ]; then
    echo -e "${YELLOW}╔════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║    ⚠️  SECURITY RISKS DETECTED     ║${NC}"
    echo -e "${YELLOW}╚════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${YELLOW}Please review the report and adjust permissions accordingly.${NC}"
else
    echo -e "${GREEN}╔════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║  ✓ ALL SECURITY CHECKS PASSED      ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════╝${NC}"
fi

echo ""
echo -e "${GREEN}✓ Security audit report created successfully${NC}"
echo -e "Report saved to: ${BLUE}$REPORT_FILE${NC}"
echo ""
echo "To view the full report, run:"
echo "  cat $REPORT_FILE"
echo ""
