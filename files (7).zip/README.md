# 🔒 CyberSec Ops: Secure Vault Challenge

A comprehensive cybersecurity project demonstrating Linux security principles, access control, and secure file management through a command-line vault system.

## 📋 Project Overview

This project implements a **Secure Vault System** that safely stores secrets, controls file access, allows secure updates, and monitors security risks. It consists of four main components:

1. **Vault Setup** - Initialize the secure vault structure
2. **Permission Management** - Configure access controls
3. **Vault Operations** - Interactive secret and log management
4. **Security Monitoring** - Audit and report on vault security

## 🎯 Features

- ✅ Secure file structure with encryption keys, secrets, and logs
- ✅ Granular permission controls (600, 640, 644)
- ✅ Interactive menu-driven operations
- ✅ Timestamped logging
- ✅ Secret management with search and replace
- ✅ Security auditing and reporting
- ✅ Access denial for sensitive keys
- ✅ Color-coded terminal output

## 📁 Project Structure

```
cybersec-vault-project/
├── vault_setup.sh         # Step 1: Initialize vault
├── vault_permissions.sh   # Step 2: Configure permissions
├── vault_ops.sh          # Step 3: Manage vault operations
├── vault_monitor.sh      # Step 4: Security monitoring
└── README.md             # Documentation
```

## 🚀 Installation & Usage

### Prerequisites

- Linux/Unix environment (Ubuntu, macOS, WSL)
- Bash shell
- Basic command-line knowledge

### Step-by-Step Guide

#### 1️⃣ Clone the Repository

```bash
git clone <your-repository-url>
cd cybersec-vault-project
```

#### 2️⃣ Make Scripts Executable

```bash
chmod +x vault_setup.sh
chmod +x vault_permissions.sh
chmod +x vault_ops.sh
chmod +x vault_monitor.sh
```

#### 3️⃣ Run Step 1: Vault Setup

```bash
./vault_setup.sh
```

This creates the `~/secure_vault` directory with three files:
- `keys.txt` - Encryption keys storage
- `secrets.txt` - Confidential data
- `logs.txt` - System logs

#### 4️⃣ Run Step 2: Configure Permissions

```bash
./vault_permissions.sh
```

This allows you to set file permissions:
- Press `y` to manually set permissions
- Press `n` to keep current permissions
- Press `Enter` to apply default secure permissions

**Default Permissions:**
- `keys.txt` → 600 (owner read/write only)
- `secrets.txt` → 640 (owner read/write, group read)
- `logs.txt` → 644 (owner read/write, all read)

#### 5️⃣ Run Step 3: Vault Operations

```bash
./vault_ops.sh
```

Interactive menu options:
1. **Add Secret** - Store new confidential data
2. **Update Secret** - Modify existing secrets
3. **Add Log Entry** - Create timestamped log entries
4. **Access Keys** - Demonstrates access denial
5. **Exit** - Close the application

#### 6️⃣ Run Step 4: Security Monitoring

```bash
./vault_monitor.sh
```

This generates a comprehensive security report showing:
- File sizes
- Last modified dates
- Current permissions
- Security risk analysis
- Recommendations

## 🛡️ Security Features

### Permission Levels

| File | Permission | Octal | Meaning |
|------|-----------|-------|---------|
| keys.txt | rw------- | 600 | Most restrictive |
| secrets.txt | rw-r----- | 640 | Group readable |
| logs.txt | rw-r--r-- | 644 | World readable |

### Security Checks

- ✅ Automatic detection of overly permissive file permissions
- ✅ Access denial for encryption keys
- ✅ Timestamped audit logging
- ✅ Automated security reporting

## 📊 Sample Output

### Vault Setup
```
================================
  Secure Vault Setup Utility
================================

Creating secure vault directory...
✓ Directory created: /home/user/secure_vault

Initializing vault files...
✓ Created: keys.txt
✓ Created: secrets.txt
✓ Created: logs.txt
```

### Security Monitor
```
╔════════════════════════════════════════════╗
║      VAULT SECURITY MONITORING SYSTEM      ║
╚════════════════════════════════════════════╝

─────────────────────────────────────
File: keys.txt
Size: 158 bytes
Last Modified: 2026-02-08 14:23:45
Permissions: 600 (rw-------)
✓ Security status: OK
```

## 🧪 Testing

Test the vault system with these scenarios:

1. **Setup Test**: Run vault_setup.sh and verify all files are created
2. **Permission Test**: Set different permissions and verify they're applied
3. **Operations Test**: Add secrets, update them, and add log entries
4. **Security Test**: Intentionally set loose permissions and verify detection

## 📚 Learning Objectives

This project demonstrates:

- ✅ Linux file system operations
- ✅ Bash scripting fundamentals
- ✅ Permission management (chmod)
- ✅ I/O redirection and file operations
- ✅ Interactive menu systems
- ✅ String manipulation with sed
- ✅ File metadata extraction (stat)
- ✅ Security best practices
- ✅ Audit logging

## 🤝 Contributing

This is a learning project. Feel free to:

- Add new features (encryption, backup, etc.)
- Improve security checks
- Enhance the user interface
- Add more comprehensive logging

## 📄 License

This project is created for educational purposes as part of the CyberSec Ops challenge.

## 👨‍💻 Author

CyberSec Ops Team - Junior Cybersecurity Training Program

## 🔗 Resources

- [Linux File Permissions Guide](https://www.linux.com/training-tutorials/understanding-linux-file-permissions/)
- [Bash Scripting Tutorial](https://www.shellscript.sh/)
- [Security Best Practices](https://www.cisecurity.org/)

---

**⚠️ Disclaimer**: This is an educational project. For production environments, use established security tools and consult with security professionals.
