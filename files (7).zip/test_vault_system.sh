#!/bin/bash

################################################################################
# Script Name: test_vault_system.sh
# Description: Automated testing script for the Secure Vault System
#              Tests all components and verifies functionality
# Author: CyberSec Ops Team
################################################################################

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   SECURE VAULT SYSTEM - AUTOMATED TESTING     ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════╝${NC}"
echo ""

# Test counter
total_tests=0
passed_tests=0
failed_tests=0

# Function to run a test
run_test() {
    local test_name="$1"
    local test_command="$2"
    
    total_tests=$((total_tests + 1))
    echo -n "Testing: $test_name... "
    
    if eval "$test_command" > /dev/null 2>&1; then
        echo -e "${GREEN}✓ PASSED${NC}"
        passed_tests=$((passed_tests + 1))
        return 0
    else
        echo -e "${RED}✗ FAILED${NC}"
        failed_tests=$((failed_tests + 1))
        return 1
    fi
}

echo -e "${YELLOW}Phase 1: Script Existence Tests${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

run_test "vault_setup.sh exists" "[ -f vault_setup.sh ]"
run_test "vault_permissions.sh exists" "[ -f vault_permissions.sh ]"
run_test "vault_ops.sh exists" "[ -f vault_ops.sh ]"
run_test "vault_monitor.sh exists" "[ -f vault_monitor.sh ]"
run_test "README.md exists" "[ -f README.md ]"

echo ""
echo -e "${YELLOW}Phase 2: Script Executability Tests${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

run_test "vault_setup.sh is executable" "[ -x vault_setup.sh ]"
run_test "vault_permissions.sh is executable" "[ -x vault_permissions.sh ]"
run_test "vault_ops.sh is executable" "[ -x vault_ops.sh ]"
run_test "vault_monitor.sh is executable" "[ -x vault_monitor.sh ]"

echo ""
echo -e "${YELLOW}Phase 3: Script Syntax Tests${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

run_test "vault_setup.sh syntax" "bash -n vault_setup.sh"
run_test "vault_permissions.sh syntax" "bash -n vault_permissions.sh"
run_test "vault_ops.sh syntax" "bash -n vault_ops.sh"
run_test "vault_monitor.sh syntax" "bash -n vault_monitor.sh"

echo ""
echo -e "${YELLOW}Phase 4: Functional Tests${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Clean up any existing test vault
if [ -d "$HOME/secure_vault" ]; then
    echo "Cleaning up previous test vault..."
    rm -rf "$HOME/secure_vault"
fi

run_test "vault_setup.sh creates directory" "./vault_setup.sh && [ -d $HOME/secure_vault ]"
run_test "keys.txt created" "[ -f $HOME/secure_vault/keys.txt ]"
run_test "secrets.txt created" "[ -f $HOME/secure_vault/secrets.txt ]"
run_test "logs.txt created" "[ -f $HOME/secure_vault/logs.txt ]"

# Test permissions script with automated input
echo -e "\n\n" | ./vault_permissions.sh > /dev/null 2>&1
run_test "vault_permissions.sh sets permissions" "[ \$(stat -c%a $HOME/secure_vault/keys.txt) -eq 600 ]"

# Test operations script
echo "5" | ./vault_ops.sh > /dev/null 2>&1
run_test "vault_ops.sh runs without errors" "[ $? -eq 0 ]"

# Test monitoring script
./vault_monitor.sh > /dev/null 2>&1
run_test "vault_monitor.sh generates report" "[ -f $HOME/secure_vault/vault_report.txt ]"

echo ""
echo -e "${YELLOW}Phase 5: Content Validation Tests${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

run_test "keys.txt has content" "[ -s $HOME/secure_vault/keys.txt ]"
run_test "secrets.txt has content" "[ -s $HOME/secure_vault/secrets.txt ]"
run_test "logs.txt has content" "[ -s $HOME/secure_vault/logs.txt ]"
run_test "vault_report.txt has content" "[ -s $HOME/secure_vault/vault_report.txt ]"

echo ""
echo -e "${YELLOW}Phase 6: Security Tests${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

run_test "keys.txt permission is 600 or less" "[ \$(stat -c%a $HOME/secure_vault/keys.txt) -le 600 ]"
run_test "secrets.txt permission is 640 or less" "[ \$(stat -c%a $HOME/secure_vault/secrets.txt) -le 640 ]"
run_test "logs.txt permission is 644 or less" "[ \$(stat -c%a $HOME/secure_vault/logs.txt) -le 644 ]"

echo ""
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo -e "${BLUE}              TEST RESULTS SUMMARY              ${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo ""
echo "Total Tests:  $total_tests"
echo -e "Passed:       ${GREEN}$passed_tests${NC}"
echo -e "Failed:       ${RED}$failed_tests${NC}"
echo ""

if [ $failed_tests -eq 0 ]; then
    echo -e "${GREEN}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║  ✓ ALL TESTS PASSED - READY TO SUBMIT!   ║${NC}"
    echo -e "${GREEN}╚═══════════════════════════════════════════╝${NC}"
    echo ""
    echo "Your Secure Vault System is working perfectly!"
    echo "You can now submit your project to GitHub."
    exit 0
else
    echo -e "${RED}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${RED}║  ✗ SOME TESTS FAILED - NEEDS ATTENTION   ║${NC}"
    echo -e "${RED}╚═══════════════════════════════════════════╝${NC}"
    echo ""
    echo "Please review the failed tests above and fix any issues."
    exit 1
fi
